SET-UP:  

Attach the Railgun Raycast script to the weapon of choice.

Make sure there is an AudioSource component attached to the gameobject which holds the weapon. The different audioclips playing are managed by the script.

There's also a reference to a particlesystem in the script. This particlesystem will display the animation of the railgun charging.

If needed, customize the public integers on the corresponding property fields of the script.

SCRIPT MECHANICS:

The script attached to the weapon will check for mousebutton input every frame in the Update function. On release, the shoot function is called and a raycast will check for collisions with gameobjects. If it hits something it will check if the gameobject has an enemyhealth script attached. If so, the takedamage function will be invoked.

USAGE:

When the railgun is equipped, hold down the mousebutton(Fire1) to charge the shot. A particlesystem should then activate to animate the charging of the railgun and the railgun charge audio clip should play.

When the mousebutton is released, the particles stop and a beam with a default range of 150 should fire and the railgun shot audio clip should play. (Standard line using line renderer or customized material).


